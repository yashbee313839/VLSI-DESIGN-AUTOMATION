#Floorplanning

import sys,getopt
from SA import *
from move import *
from polish_validity import *
from node import *
from cost import *
import random
import copy
import itertools
import numpy as np
import math
import turtle
from iscas_parser import *

polish_exp = []
dim_list = []
costarray = []

def main(argv):
   file_root= ''
   rotate="true"
   try:
      opts, args = getopt.getopt(argv,"hi:a:t:r:l:",["ifile="])
   except getopt.GetoptError:
      print('Partition.py -i <inputfile> -a <Algorithm>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print('placement.py -i <inputfile> -r <Rotate-true/false>')
         sys.exit()
      elif opt in ('-i', "--ifile"):
         file_root = arg
      elif opt in ('-r'):
         rotate = arg
   print("\n")
   print('Input file is ', file_root)
   print('Rotation applied', rotate)
   print("\n")
   return file_root,rotate

if __name__ == "__main__":
   file_root,rotate = main(sys.argv[1:])
   
   if(rotate=="true"):
       rotate=1
   else:
       rotate=0

   with open (file_root, "r") as myfile:
      file=myfile.read()
   
   adjacency_list = parse_iscas(file)
   print("\n")

#   for i in range(1, len(adjacency_list) + 1 - int(len(adjacency_list)/2)):
#       polish_exp.append(str(i))
#   for i in range(0, len(adjacency_list) - 1 - int(len(adjacency_list)/2)):
#       if random.uniform(0, 1) < 0.5:
#           polish_exp.append("V")
#       else:
#           polish_exp.append("H")
#   for i in range(len(adjacency_list) + 1 - int(len(adjacency_list)/2), len(adjacency_list) + 1):
#       polish_exp.append(str(i))
#   for i in range(len(adjacency_list) - 1 - int(len(adjacency_list)/2), len(adjacency_list) - 1):
#       if random.uniform(0, 1) < 0.5:
#           polish_exp.append("V")
#       else:
#           polish_exp.append("H")

   for i in range(1, int(len(adjacency_list)/16)):
       polish_exp.append(str(i))
   for i in range(0, int(len(adjacency_list)/16)-2):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)/16), int(len(adjacency_list)/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/16), int(len(adjacency_list)/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/8), int(len(adjacency_list)*3/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/8), int(len(adjacency_list)*3/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*3/16), int(len(adjacency_list)/4)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/16), int(len(adjacency_list)/4)+1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/4), int(len(adjacency_list)*5/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/4), int(len(adjacency_list)*5/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*5/16), int(len(adjacency_list)*3/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*5/16), int(len(adjacency_list)*3/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*3/8), int(len(adjacency_list)*7/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/8), int(len(adjacency_list)*7/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*7/16), int(len(adjacency_list)/2)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*7/16), int(len(adjacency_list)/2) + 2):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/2), int(len(adjacency_list)*9/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/2), int(len(adjacency_list)*9/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*9/16), int(len(adjacency_list)*5/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*9/16), int(len(adjacency_list)*5/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*5/8), int(len(adjacency_list)*11/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*5/8), int(len(adjacency_list)*11/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*11/16), int(len(adjacency_list)*3/4)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*11/16), int(len(adjacency_list)*3/4)+1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*3/4), int(len(adjacency_list)*13/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/4), int(len(adjacency_list)*13/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*13/16), int(len(adjacency_list)*7/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*13/16), int(len(adjacency_list)*7/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*7/8), int(len(adjacency_list)*15/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*7/8), int(len(adjacency_list)*15/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*15/16), int(len(adjacency_list))):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*15/16), int(len(adjacency_list)) + 3):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
####
   for i in range(0,len(adjacency_list)):
       x = []
       x.append(random.randint(4,6))
       x.append(random.randint(4,6))
       dim_list.append(x)

   extra_width = []
   for i in range(0, len(adjacency_list)):
       count = 0
       for j in range(0, len(adjacency_list)):
           if adjacency_list[i][j] > 0:
               count += 0.2
       dim_list[i][0] += int(len(adjacency_list)/4 * count)
       dim_list[i][1] += int(len(adjacency_list)/4 * count)
       extra_width.append(count)

   output = open('../data_files/Placement_Block_Size.txt', 'w')
   print("LIST OF SIZES OF BLOCKS",file=output)
   for i in range(0,len(dim_list)):
       print("BLOCK ",i+1,",","SIZE =",dim_list[i],file=output)
   if rotate == 1:
       print("ROTATION ENABLED",file=output)
   else:
       print("ROTATION DISABLED",file=output)


   print("Initial Polish expression:", polish_exp)
   print("\n")
   print("\n")
   [HPWL,initial_cost,coordinates,dimensions,min_dim] = cost(polish_exp,copy.deepcopy(dim_list),rotate,adjacency_list)

   costarray.append(initial_cost)
   for i in range(0, 3):
       random_num = random.uniform(0, 1)
       if random_num < 0.4:
           polish_expnew = move_m1(polish_exp)
       
       elif random_num < 0.8:
           polish_expnew = move_m2(polish_exp)
       
       else:
           polish_expnew = move_m3(polish_exp)
        
       polish_exp = polish_expnew
       [HPWL, new_cost, coordinates,dimensions,min_dim] = cost(polish_expnew, copy.deepcopy(dim_list), rotate,adjacency_list)
   
       costarray.append(new_cost)
       sum = 0
   for j in range(0, 3):
       sum += abs(costarray[j] - costarray[j + 1])
   delta_ave = sum / 3
   initial_temp = -delta_ave / math.log(0.9)
   if initial_temp == 0:
       initial_temp = 100 * len(adjacency_list)
   print("Initial Temperature=", initial_temp)
   print("\n")

   final_expression,cost_plot = SA(polish_exp, initial_temp,adjacency_list,copy.deepcopy(dim_list),rotate)
   Draw_cost_plot(cost_plot)
   print("final Polish expression", final_expression)

   [HPWL,cost_area,coordinates,dimensions,min_dim] = cost(final_expression,copy.deepcopy(dim_list),rotate,adjacency_list)
   for i in range(0, len(adjacency_list)):
      dimensions[i][0] -= int(len(adjacency_list)/4 * extra_width[i])/2
      dimensions[i][1] -= int(len(adjacency_list)/4 * extra_width[i])/2

   print("\n")
   print("HPWL=", HPWL)
   print("\n")
   print("Area Occupied=", cost_area)
   print("\n")
   print("Coordinates Of the Blocks=", coordinates)
   print("\n")
   print("Dimensions Of the Blocks=", dimensions)
   print("\n")
   print("Blocksize Of Blocks=", min_dim)


   np.save("../data_files/coordinates", np.array(coordinates))
   np.save("../data_files/dimensions", np.array(dimensions))
   np.save("../data_files/min_dim", np.array(min_dim))
   np.save("../data_files/adjacency_list", np.array(adjacency_list))


   window_dim = np.max(coordinates,axis=0)
   turtle.ht()
   #turtle.Screen().screensize(2000,1300)
   turtle.Screen().setup(width=1.0,height=1.0)
   turtle.setworldcoordinates(-1,-1,window_dim[0]+100,window_dim[1]+100)
  
   color = ["#9400D3","#4B0082","#0000FF","#00FF00","#FFFF00","#FF7F00","#FF0000"]

   for i in range(0, len(adjacency_list)):
       centre_x = coordinates[i][0]
       centre_y = coordinates[i][1]
       width = dimensions[i][0]
       height = dimensions[i][1]
       turtle.penup()
       turtle.goto(centre_x + width / 2, centre_y + height / 2)
       turtle.pendown()
       turtle.fillcolor(color[i%7])
       turtle.begin_fill()
       turtle.goto(centre_x - width / 2, centre_y + height / 2)
       turtle.goto(centre_x - width / 2, centre_y - height / 2)
       turtle.goto(centre_x + width / 2, centre_y - height / 2)
       turtle.goto(centre_x + width / 2, centre_y + height / 2)
       turtle.end_fill()

   print("done")
   ts = turtle.getscreen()
   ts.getcanvas().postscript(file="../data_files/Final_placement.eps")
   turtle.ht()
   turtle.done()