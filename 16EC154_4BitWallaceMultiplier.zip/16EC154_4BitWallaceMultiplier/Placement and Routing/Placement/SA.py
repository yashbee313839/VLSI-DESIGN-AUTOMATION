import random
import copy
import itertools
import numpy as np
import math
import matplotlib.pyplot as plt
from cost import *
from move import *


def Draw_cost_plot(cost_plot):
        plt.plot(cost_plot[0],cost_plot[1])
        plt.xlabel("No of Iterations")
        plt.ylabel("Cost")
        plt.show()

def SA(polish_exp, initial_temp,adjacency_list,dim_list,rotate):

    temp = initial_temp
    polish_expold = polish_exp
    total_attempts = 0
    [HPWL, F_old, coordinates,dimensions,min_dim] = cost(polish_exp, copy.deepcopy(dim_list), rotate,adjacency_list)
    cost_plot = [[total_attempts],[F_old]]
        # iterations
    while (1):
        uphill_moves = 0
        accepted_moves = 0
        max_iterations_per_temperature = 200
        for q in range(0, max_iterations_per_temperature):

            total_attempts += 1
            [HPWL, F_old, coordinates,dimensions,min_dim] = cost(polish_exp, copy.deepcopy(dim_list), rotate,adjacency_list)
         
            random_num = random.uniform(0, 1)
            if random_num < 0.2:
                polish_expnew = move_m1(polish_exp)
            
            elif random_num < 0.4:
                polish_expnew = move_m2(polish_exp)
               
            else:
                polish_expnew = move_m3(polish_exp)
            
            [HPWL1, F_new, coordinates,dimensions,min_dim] = cost(polish_expnew, copy.deepcopy(dim_list), rotate,adjacency_list)
          
            delta = F_new - F_old + 0.1 * (HPWL1 - HPWL)
               

            if ((delta <= 0) or ((delta > 0) and (np.random.uniform() < math.exp(-delta / temp)))):
                if delta>0:
                    uphill_moves+=1
                polish_exp = polish_expnew
                accepted_moves += 1
                cost_plot[0].append(total_attempts)
                cost_plot[1].append(F_new)
            else:
                cost_plot[0].append(total_attempts)
                cost_plot[1].append(F_old)
               
        temp = 0.95 * temp;
        if (accepted_moves < 0.1 * max_iterations_per_temperature) or (temp < 0.01) or total_attempts >= 1000:
            break

       
    return polish_exp,cost_plot