class cell:
    def __init__(self, value=0, block=0, direction=None, routed = 0):
        self.value = value
        self.block = block
        self.direction = direction
        self.routed = routed