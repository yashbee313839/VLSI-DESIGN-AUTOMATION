import random
import copy
import itertools
import numpy as np
import math
from node import *


def construct_slicing_tree(polish_exp,eval_list):
        nodes_list = []
        j = 0
        for i in polish_exp:
            if not i.isalpha():
                nodes_list.append(i)
            else:
                a = nodes_list.pop()
                b = nodes_list.pop()
                root = node(i, eval_list[j])
                if type(b) == str:
                    root.left_insert(b, eval_list[polish_exp.index(b)])
                else:
                    root.left_insert(b, 0)
                if type(a) == str:
                    root.right_insert(a, eval_list[polish_exp.index(a)])
                else:
                    root.right_insert(a, 0)
                nodes_list.append(root)
            j = j + 1
        root = nodes_list.pop()
        return root


def minimum_area(polish_exp,dim_list,rotate):
        nodes_list = []
        nodes_list_1 = []
        for i in polish_exp:
            if not i.isalpha():
                if rotate == 0:
                    nodes_list.append([dim_list[int(i)-1]])
                    nodes_list_1.append([dim_list[int(i)-1]])
                else:
                    p = []
                    q = dim_list[int(i)-1]
                    r = copy.deepcopy(dim_list[int(i)-1])
                    p.append(q)
                    r.reverse()
                    if r not in p:
                        p.append(r)
                    nodes_list.append(p)
                    nodes_list_1.append(p)

            else:
                a = nodes_list.pop()
                b = nodes_list.pop()
                a.sort(key=lambda x: x[0])
                b.sort(key=lambda x: x[0])
                a.reverse()
                b.reverse()
                j = 0
                k = 0
                evaluated_dim = []
                dimensions = []
                if i == 'H':
                    while j < len(a) and k < len(b):
                        if a[j][0] >= b[k][0]:
                            evaluated_dim.append([a[j][0], a[j][1] + b[k][1]])
                            j = j+1
                        else:
                            evaluated_dim.append([b[k][0], a[j][1] + b[k][1]])
                            k = k+1
                else:
                    while j<len(a) and k<len(b):
                        if a[j][1] >= b[k][1]:
                            evaluated_dim.append([a[j][0] + b[k][0], a[j][1]])
                            j = j+1
                        else:
                            evaluated_dim.append([a[j][0] + b[k][0], b[k][1]])
                            k = k+1
                nodes_list_1.append(evaluated_dim)
                nodes_list.append(evaluated_dim)
        nodes_list = nodes_list.pop()
        j = 0
        for i in nodes_list:
            area = i[0]*i[1]
            if nodes_list.index(i) == 0:
                min_area = area
                j = i
            elif area < min_area:
                min_area = area
                j = i
        return min_area,nodes_list_1,j


def find_min_block_dim(root,min_dim,sizes):
        stack = []
        stack.append([root,min_dim])
        while len(stack)!=0:
            x = stack.pop()
            root = x[0]
            min_dim = x[1]
            root.dim = min_dim
            root.coordinates = [x/2 for x in min_dim]
            flag=0
            if root.data == 'H':
                a = root.left.dim
                b = root.right.dim
                for i in a:
                    for j in b:
                        dim = [max([i[0],j[0]]),i[1]+j[1]]
                        if min_dim == dim:
                            stack.append([root.left,i])
                            stack.append([root.right,j])
                            flag=1
                            break
                    if flag==1:
                        break
            elif root.data == 'V':
                a = root.left.dim
                b = root.right.dim
                for i in a:
                    for j in b:
                        dim = [i[0]+j[0],max([i[1],j[1]])]
                        if min_dim == dim:
                            stack.append([root.left,i])
                            stack.append([root.right,j])
                            flag=1
                            break
                    if flag==1:
                        break
            else:
                sizes[int(root.data)-1] = min_dim
                root.dim = min_dim
                root.coordinates = [x/2 for x in min_dim]


def find_coordinates(root,coordinates):
        stack = []
        stack.append([root,[0,0]])
        while len(stack) != 0:
            x = stack.pop()
            root = x[0]
            change_W = x[1][0]
            change_H = x[1][1]
            if root.data == 'H':
                a = root.left.dim
                b = root.right.coordinates
                c = root.left.coordinates
                root.right.coordinates = [b[0]+change_W,b[1]+a[1]+change_H]
                root.left.coordinates = [c[0]+change_W,c[1]+change_H]
                stack.append([root.left, [change_W, change_H]])
                change_H = change_H + a[1]
                stack.append([root.right,[change_W,change_H]])
            elif root.data == 'V':
                a = root.left.dim
                b = root.right.coordinates
                c = root.left.coordinates
                root.right.coordinates = [b[0]+a[0]+change_W,b[1]+change_H]
                root.left.coordinates = [c[0]+change_W,c[1]+change_H]
                stack.append([root.left, [change_W, change_H]])
                change_W = change_W + a[0]
                stack.append([root.right, [change_W, change_H]])
            else:
                coordinates[int(root.data)-1] = root.coordinates

def cost(polish_exp,dim_list,rotate,adjacency_list):
          [cost_area,nodes_list,min_dim] = minimum_area(polish_exp,dim_list,rotate)
          root = construct_slicing_tree(polish_exp, nodes_list)
          root1 = root
          find_min_block_dim(root,min_dim,dim_list)
          find_coordinates(root1,dim_list)

          HPWL = 0
          for i in range(1,len(adjacency_list)+1):
              x = []
              y = []
              weight = 0
              x.append(dim_list[i-1][0])
              y.append(dim_list[i-1][1])
              for j in range(1,len(adjacency_list)+1):
                  if adjacency_list[i-1][j-1] != 0:
                     weight = weight + adjacency_list[i-1][j-1]
                     x.append(dim_list[j-1][0])
                     y.append(dim_list[j-1][1])
              min_x = min(x)
              max_x = max(x)
              min_y = min(y)
              max_y = max(y)
              HPWL = HPWL + weight*(max_x+max_y-min_x-min_y)

          return HPWL,cost_area,dim_list