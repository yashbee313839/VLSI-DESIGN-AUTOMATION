import random
import copy
import itertools
import numpy as np
import math

def valid_polish(polish_exp,swap_pos):
    valid=1
    count=0
    for i in range(0,swap_pos+1):
        if polish_exp[i].isalpha() ==1 :
            count+=1

    for i in range(0,len(polish_exp)):
        if i!=len(polish_exp)-1 and polish_exp[i]=='H' and polish_exp[i+1]=='H' or i!=len(polish_exp)-1 and polish_exp[i]=='V' and polish_exp[i+1]=='V':
            valid=0
            break
    if 2*count< swap_pos+1  and valid==1:
        return 1
    else:
        return 0