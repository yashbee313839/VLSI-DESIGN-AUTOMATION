import random
import copy
import itertools
import numpy as np
import math
from polish_validity import *

def move_m1(polish_exp):
    indices = []
    indices2 = []
    length = len(polish_exp)
    for i in range(0, length):
        if (i != length - 1 and polish_exp[i].isdigit() and polish_exp[i + 1].isdigit()):
            indices.append(i)
            i += 1
        elif (i < length - 2 and polish_exp[i].isdigit() and polish_exp[i + 1].isalpha() and polish_exp[
            i + 2].isdigit()):
            indices2.append(i)
            i += 1
    indicesfinal = indices + indices2
    random_index = random.randint(0, len(indicesfinal) - 1)
    polish_exp = list(polish_exp)
    if indicesfinal[random_index] in indices:
        temp = polish_exp[indicesfinal[random_index]]
        polish_exp[indicesfinal[random_index]] = polish_exp[indicesfinal[random_index] + 1]
        polish_exp[indicesfinal[random_index] + 1] = temp
    else:
        temp = polish_exp[indicesfinal[random_index]]
        polish_exp[indicesfinal[random_index]] = polish_exp[indicesfinal[random_index] + 2]
        polish_exp[indicesfinal[random_index] + 2] = temp
    return polish_exp;


def move_m2(polish_exp):
    indices = []
    i = 0
    length = len(polish_exp)
    while i != length - 1:
        if (polish_exp[i].isalpha() and polish_exp[i + 1].isalpha()):
            indices.append(i)
            while i != length - 1 and polish_exp[i].isdigit() != 1:
                i = i +1
        else:
            i = i + 1
    if indices == []:
        return polish_exp

    else:
        random_index = random.randint(0, len(indices) - 1)
        polish_exp = list(polish_exp)
        j = indices[random_index]
        while j != length and polish_exp[j].isdigit() != 1:
            if polish_exp[j] == 'H':
                polish_exp[j] = 'V'
            else:
                polish_exp[j] = 'H'
            j = j + 1
        return polish_exp;

def move_m3(polish_exp):
    polish_old=polish_exp
    indices = []
    length = len(polish_exp)
    for i in range (0,length):
        if (i!=length-1 and (polish_exp[i].isalpha() and polish_exp[i+1].isdigit() or polish_exp[i].isdigit() and polish_exp[i+1].isalpha() )):
            indices.append(i)
    random_index=random.randint(0,len(indices)-1)
    polish_exp=list(polish_exp)
    temp=polish_exp[indices[random_index]]
    polish_exp[indices[random_index]]=polish_exp[indices[random_index]+1]
    polish_exp[indices[random_index]+1]=temp
    valid_var = valid_polish(polish_exp, indices[random_index])
    if valid_var != 1:
        polish_exp=move_m2(polish_old)

    return polish_exp;

