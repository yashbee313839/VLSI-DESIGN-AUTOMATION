#Floorplanning

import sys,getopt
from SA import *
from move import *
from polish_validity import *
from node import *
from cost import *
import random
import copy
import itertools
import numpy as np
import math
from iscas_parser import *

polish_exp = []
dim_list = []
costarray = []

def main(argv):
   file_root= ''
   rotate="true"
   try:
      opts, args = getopt.getopt(argv,"hi:a:t:r:l:",["ifile="])
   except getopt.GetoptError:
      print('Partition.py -i <inputfile> -a <Algorithm>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print('floorplanning.py -i <inputfile> -r <Rotate-true/false>')
         sys.exit()
      elif opt in ('-i', "--ifile"):
         file_root = arg
      elif opt in ('-r'):
         rotate = arg
   print("\n")
   print('Input file is ', file_root)
   print('Rotation applied', rotate)
   print("\n")
   return file_root,rotate

if __name__ == "__main__":
   file_root,rotate = main(sys.argv[1:])
   
   if(rotate=="true"):
       rotate=1
   else:
       rotate=0

   with open (file_root, "r") as myfile:
      file=myfile.read()
   
   adjacency_list = parse_iscas(file)
   print("\n")

   for i in range(1, int(len(adjacency_list)/16)):
       polish_exp.append(str(i))
   for i in range(0, int(len(adjacency_list)/16)-2):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)/16), int(len(adjacency_list)/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/16), int(len(adjacency_list)/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/8), int(len(adjacency_list)*3/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/8), int(len(adjacency_list)*3/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*3/16), int(len(adjacency_list)/4)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/16), int(len(adjacency_list)/4)+1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/4), int(len(adjacency_list)*5/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/4), int(len(adjacency_list)*5/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*5/16), int(len(adjacency_list)*3/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*5/16), int(len(adjacency_list)*3/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*3/8), int(len(adjacency_list)*7/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/8), int(len(adjacency_list)*7/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*7/16), int(len(adjacency_list)/2)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*7/16), int(len(adjacency_list)/2) + 2):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)/2), int(len(adjacency_list)*9/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)/2), int(len(adjacency_list)*9/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*9/16), int(len(adjacency_list)*5/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*9/16), int(len(adjacency_list)*5/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*5/8), int(len(adjacency_list)*11/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*5/8), int(len(adjacency_list)*11/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*11/16), int(len(adjacency_list)*3/4)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*11/16), int(len(adjacency_list)*3/4)+1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*3/4), int(len(adjacency_list)*13/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*3/4), int(len(adjacency_list)*13/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*13/16), int(len(adjacency_list)*7/8)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*13/16), int(len(adjacency_list)*7/8)):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(int(len(adjacency_list)*7/8), int(len(adjacency_list)*15/16)):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*7/8), int(len(adjacency_list)*15/16)-1):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")
   for i in range(int(len(adjacency_list)*15/16), int(len(adjacency_list))):
       polish_exp.append(str(i))
   for i in range(int(len(adjacency_list)*15/16), int(len(adjacency_list)) + 3):
       if random.uniform(0, 1) < 0.5:
           polish_exp.append("V")
       else:
           polish_exp.append("H")

   for i in range(0,len(adjacency_list)):
       x = []
       x.append(random.randint(1,10))
       x.append(random.randint(1, 10))
       dim_list.append(x)

   output = open('data_files/Placement_Block_Size.txt', 'w')
   print("LIST OF SIZES OF BLOCKS",file=output)
   for i in range(0,len(dim_list)):
       print("BLOCK ",i+1,",","SIZE =",dim_list[i],file=output)
   if rotate == 1:
       print("ROTATION ENABLED",file=output)
   else:
       print("ROTATION DISABLED",file=output)


   [HPWL,initial_cost,coordinates] = cost(polish_exp,copy.deepcopy(dim_list),rotate,adjacency_list)
   print("Initial Polish Expression:",polish_exp)
   print("\n")
   print("\n")
   costarray.append(initial_cost)
   for i in range(0, 3):
       random_num = random.uniform(0, 1)
       if random_num < 0.2:
           polish_expnew = move_m1(polish_exp)
       
       elif random_num < 0.5:
           polish_expnew = move_m2(polish_exp)
       
       else:
           polish_expnew = move_m3(polish_exp)
        
       polish_exp = polish_expnew
       [HPWL, new_cost, coordinates] = cost(polish_expnew, copy.deepcopy(dim_list), rotate,adjacency_list)
   
       costarray.append(new_cost)
       sum = 0
   for j in range(0, 3):
       sum += abs(costarray[j] - costarray[j + 1])
   delta_ave = sum / 3
   initial_temp = -delta_ave / math.log(0.9)
   print("Initial Temperature", initial_temp)
   print("\n")

   final_expression,cost_plot = SA(polish_exp, initial_temp,adjacency_list,copy.deepcopy(dim_list),rotate)
   print("final Polish expression", final_expression)
   Draw_cost_plot(cost_plot)

   [HPWL,cost_area,coordinates] = cost(final_expression,copy.deepcopy(dim_list),rotate,adjacency_list)
   print("\n")
   print("HPWL=",HPWL)
   print("\n")
   print("Area Occupied=",cost_area)
   print("\n")
   print("Coordinates of the Blocks=",coordinates)