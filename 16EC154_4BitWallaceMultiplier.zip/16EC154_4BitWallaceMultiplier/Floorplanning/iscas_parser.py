import random
import copy
import itertools
import numpy as np
import math

def parse_iscas(file):
  print("Parsing Started!!!")
  
  split_list = file.split('\n')
  No_gates=0

  for op in split_list:
    if '=' in op:
      No_gates += 1

  output_array = []
  input_array = []

  for op in split_list:
    if 'INPUT' in op:
      No_gates += 1
      open_brace_index = op.find('(',0)
      close_brace_index = op.find(')',0)
      op_G = op[open_brace_index+1:close_brace_index]
      inp=int(op_G[1:])
      output_array.append(inp)
      input_array.append([-1])

  adj_mx = np.zeros((No_gates,No_gates))

  for op in split_list:
    if '=' in op:
      G_index = op.find('G',0)
      equal_index = op.find('=',0)
      out = int(op[G_index+1:equal_index-1])
      output_array.append(out)


  for op in split_list:
    if '=' in op:
      open_brace_index = op.find('(',0)
      close_brace_index = op.find(')',0)
      op_sub = op[open_brace_index+1:close_brace_index]
      op_sub_G_list = op_sub.split(',')
      in_array = []
      for item in op_sub_G_list:
        G_index = item.find('G',0)
        inp = int(item[G_index+1:])
        in_array.append(inp)
      input_array.append(in_array)

  for i in range(len(input_array)):
    for j in range(len(input_array[i])):
      if(input_array[i][j]!=-1):
        adj_mx_i = output_array.index(input_array[i][j])
        adj_mx_j = i
        adj_mx[adj_mx_i][adj_mx_j] = 1

  print("Successfully Parsed!!!")

  return adj_mx