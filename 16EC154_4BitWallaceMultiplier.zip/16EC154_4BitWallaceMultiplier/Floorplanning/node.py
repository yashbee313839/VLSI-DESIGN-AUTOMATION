import random
import copy
import itertools
import numpy as np
import math

class node:

        def __init__(self, data, dim):

            self.left = None
            self.right = None
            self.data = data
            self.dim = dim
            self.coordinates = 0

        def postorder(self):

            if self.left is not None:
                self.left.postorder()
            if self.right is not None:
                self.right.postorder()
            print(self.data,':',self.dim,':',self.coordinates, end='')

        def left_insert(self, data, dim):

            if self.left is None:
                if type(data) == str:
                    self.left = node(data, dim)
                else:
                    self.left = data

        def right_insert(self, data, dim):

            if self.right is None:
                if type(data) == str:
                    self.right = node(data, dim)
                else:
                    self.right = data
